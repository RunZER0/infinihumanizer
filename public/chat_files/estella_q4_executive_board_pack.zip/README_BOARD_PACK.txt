Estella Williams — Q4 Executive Board Package
Includes: 16-Slide Board Deck (.pptx), Cap Table & Projections (.xlsx), Briefing Memo (.docx).