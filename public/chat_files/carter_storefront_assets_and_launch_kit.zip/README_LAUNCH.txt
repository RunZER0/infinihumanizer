Carter Lemburg — ApexDesk Launch Kit
Includes: HTML Prototype, CSS Stylesheet, Launch Checklist, Asset Manifest.