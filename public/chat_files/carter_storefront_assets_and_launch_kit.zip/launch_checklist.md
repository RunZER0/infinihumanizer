# ApexDesk Storefront Launch Checklist

- [x] Configure Shopify variant SKUs (AD-01 Matte Black, AD-02 Silver)
- [x] Integrate 15W Qi2 fast-charging compliance badge
- [x] Set up abandoned cart recovery email trigger (1hr / 24hr)
- [x] Test Apple Pay and Google Pay express checkout buttons